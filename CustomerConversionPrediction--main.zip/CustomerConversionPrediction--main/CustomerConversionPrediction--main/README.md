Hi this project is based on customer conversion prediction
and help to predict the customer conversion.
 
